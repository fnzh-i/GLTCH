import { useState, useMemo } from "react";
import { motion, AnimatePresence, LayoutGroup } from "motion/react";
import { Clock, MapPin, ChevronDown, ChevronUp, Filter } from "lucide-react";
import talksData from "../../data/talks.json";

type Talk = {
  id: number;
  title: string;
  speaker: string;
  role: string;
  day: number;
  time: string;
  duration: number;
  track: string;
  room: string;
  description: string;
};

const talks: Talk[] = talksData as Talk[];

const TRACK_COLORS: Record<string, { bg: string; border: string; text: string }> = {
  Design: { bg: "rgba(255,0,102,0.12)", border: "rgba(255,0,102,0.4)", text: "#ff0066" },
  Code: { bg: "rgba(0,212,255,0.12)", border: "rgba(0,212,255,0.4)", text: "#00d4ff" },
  AI: { bg: "rgba(124,58,237,0.12)", border: "rgba(124,58,237,0.4)", text: "#a78bfa" },
  Culture: { bg: "rgba(0,255,136,0.12)", border: "rgba(0,255,136,0.4)", text: "#00ff88" },
};

const ROOM_COLORS: Record<string, string> = {
  "Main Stage": "#ffaa00",
  "Studio A": "#ff0066",
  "Lab B": "#00d4ff",
  "Signal Room": "#a78bfa",
};

const TRACKS = ["All", "Design", "Code", "AI", "Culture"];
const DAYS = [0, 1, 2, 3];
const DAY_LABELS = ["All Days", "Day 1 — Genesis", "Day 2 — Divergence", "Day 3 — Synthesis"];
const DAY_SHORT = ["All", "Day 1", "Day 2", "Day 3"];

const AVATAR_COLORS: Record<string, string[]> = {
  "Maya Chen": ["#00ff88", "#00d4ff"],
  "Rafael Torres": ["#ff0066", "#7c3aed"],
  "Kenji Nakamura": ["#00d4ff", "#7c3aed"],
  "Zara Ahmed": ["#7c3aed", "#ff0066"],
  "Lena Kovacs": ["#ff0066", "#ffaa00"],
  "Sam Okafor": ["#00d4ff", "#00ff88"],
  "Dr. Priya Singh": ["#a78bfa", "#ff0066"],
  "Finn O'Brien": ["#ff0066", "#00d4ff"],
  "Yuki Tanaka": ["#00d4ff", "#00ff88"],
  "Amara Johnson": ["#a78bfa", "#00d4ff"],
  "Nico Ferreira": ["#ff0066", "#ffaa00"],
  "Eva Müller": ["#00d4ff", "#a78bfa"],
  "Leo Park": ["#00ff88", "#ffaa00"],
  "Cassandra Wu": ["#a78bfa", "#ff0066"],
  "Marco Ricci": ["#ffaa00", "#ff0066"],
  "Nadia Petrova": ["#00d4ff", "#7c3aed"],
  "Oliver Hayes": ["#00ff88", "#7c3aed"],
  "Aisha Malik": ["#ff0066", "#00d4ff"],
  "Jake Morrison": ["#a78bfa", "#00ff88"],
  "Sofia Delgado": ["#ffaa00", "#ff0066"],
  "Ryan Carrington": ["#00d4ff", "#a78bfa"],
  "Luna Vasquez": ["#ff0066", "#ffaa00"],
  "Ben Clarke": ["#00ff88", "#00d4ff"],
  "Maria Santos": ["#00ff88", "#a78bfa"],
  "David Osei": ["#ffaa00", "#ff0066"],
};

function getInitials(name: string) {
  return name
    .split(" ")
    .slice(0, 2)
    .map((n) => n[0])
    .join("")
    .toUpperCase();
}

function TalkCard({ talk, expanded, onToggle }: { talk: Talk; expanded: boolean; onToggle: () => void }) {
  const track = TRACK_COLORS[talk.track] || TRACK_COLORS.Culture;
  const colors = AVATAR_COLORS[talk.speaker] || ["#00ff88", "#00d4ff"];

  return (
    <motion.div
      layout
      style={{
        background: "rgba(255,255,255,0.028)",
        border: `1px solid ${expanded ? track.border : "rgba(255,255,255,0.07)"}`,
        borderRadius: "16px",
        overflow: "hidden",
        cursor: "pointer",
        transition: "border-color 0.2s ease",
      }}
      whileHover={{ borderColor: track.border, background: "rgba(255,255,255,0.045)" }}
      onClick={onToggle}
    >
      <div style={{ padding: "1.25rem 1.5rem" }}>
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            {/* Time + Track row */}
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span style={{
                fontFamily: "'DM Mono', monospace",
                fontSize: "0.72rem",
                letterSpacing: "0.08em",
                color: "rgba(255,255,255,0.4)",
                display: "flex",
                alignItems: "center",
                gap: "0.3rem",
              }}>
                <Clock size={11} />
                {talk.time}
              </span>
              <span style={{
                fontFamily: "'DM Mono', monospace",
                fontSize: "0.62rem",
                letterSpacing: "0.1em",
                color: track.text,
                background: track.bg,
                border: `1px solid ${track.border}`,
                borderRadius: "4px",
                padding: "0.15rem 0.45rem",
              }}>
                {talk.track.toUpperCase()}
              </span>
              <span style={{
                fontFamily: "'DM Mono', monospace",
                fontSize: "0.62rem",
                letterSpacing: "0.1em",
                color: ROOM_COLORS[talk.room] || "rgba(255,255,255,0.4)",
                background: "rgba(255,255,255,0.05)",
                border: "1px solid rgba(255,255,255,0.08)",
                borderRadius: "4px",
                padding: "0.15rem 0.45rem",
                display: "flex",
                alignItems: "center",
                gap: "0.25rem",
              }}>
                <MapPin size={9} />
                {talk.room}
              </span>
            </div>

            {/* Title */}
            <h3 style={{
              fontFamily: "'Space Grotesk', sans-serif",
              fontSize: "clamp(0.9rem, 2vw, 1.05rem)",
              fontWeight: 600,
              color: "#ffffff",
              margin: "0 0 0.75rem",
              lineHeight: 1.35,
            }}>
              {talk.title}
            </h3>

            {/* Speaker */}
            <div className="flex items-center gap-2">
              <div style={{
                width: 28, height: 28, borderRadius: "50%",
                background: `linear-gradient(135deg, ${colors[0]}, ${colors[1]})`,
                display: "flex", alignItems: "center", justifyContent: "center",
                flexShrink: 0,
                boxShadow: `0 0 12px ${colors[0]}33`,
              }}>
                <span style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: "0.6rem", color: "#050508" }}>
                  {getInitials(talk.speaker)}
                </span>
              </div>
              <div>
                <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: "0.82rem", fontWeight: 600, color: "rgba(255,255,255,0.85)" }}>
                  {talk.speaker}
                </div>
                <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: "0.72rem", color: "rgba(255,255,255,0.38)" }}>
                  {talk.role}
                </div>
              </div>
            </div>
          </div>

          {/* Duration + expand */}
          <div className="flex flex-col items-end gap-2 flex-shrink-0">
            <span style={{
              fontFamily: "'DM Mono', monospace",
              fontSize: "0.65rem",
              letterSpacing: "0.08em",
              color: "rgba(255,255,255,0.28)",
            }}>
              {talk.duration}m
            </span>
            <motion.div
              animate={{ rotate: expanded ? 180 : 0 }}
              transition={{ duration: 0.2 }}
              style={{ color: "rgba(255,255,255,0.3)" }}
            >
              <ChevronDown size={16} />
            </motion.div>
          </div>
        </div>

        {/* Expanded description */}
        <AnimatePresence>
          {expanded && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              style={{ overflow: "hidden" }}
            >
              <div style={{
                marginTop: "1rem",
                paddingTop: "1rem",
                borderTop: `1px solid rgba(255,255,255,0.07)`,
              }}>
                <p style={{
                  fontFamily: "'Space Grotesk', sans-serif",
                  fontSize: "0.88rem",
                  color: "rgba(255,255,255,0.5)",
                  lineHeight: 1.7,
                  margin: 0,
                }}>
                  {talk.description}
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

export default function Schedule() {
  const [selectedDay, setSelectedDay] = useState(0);
  const [selectedTrack, setSelectedTrack] = useState("All");
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [showFilters, setShowFilters] = useState(false);

  const filteredTalks = useMemo(() => {
    return talks
      .filter((t) => (selectedDay === 0 ? true : t.day === selectedDay))
      .filter((t) => (selectedTrack === "All" ? true : t.track === selectedTrack))
      .sort((a, b) => {
        if (a.day !== b.day) return a.day - b.day;
        return a.time.localeCompare(b.time);
      });
  }, [selectedDay, selectedTrack]);

  const counts = useMemo(() => {
    const base = selectedDay === 0 ? talks : talks.filter((t) => t.day === selectedDay);
    return {
      All: base.length,
      ...Object.fromEntries(TRACKS.slice(1).map((tr) => [tr, base.filter((t) => t.track === tr).length])),
    };
  }, [selectedDay]);

  return (
    <div style={{ background: "#050508", minHeight: "100vh", paddingTop: "5rem" }}>
      <style>{`
        @keyframes float-orb {
          0%, 100% { transform: translate(0, 0); }
          50% { transform: translate(20px, -20px); }
        }
      `}</style>

      {/* Background orbs */}
      <div style={{ position: "fixed", top: "20%", right: "5%", width: 300, height: 300, borderRadius: "50%", background: "rgba(0,212,255,0.04)", filter: "blur(80px)", pointerEvents: "none", animation: "float-orb 12s ease-in-out infinite" }} />
      <div style={{ position: "fixed", bottom: "10%", left: "5%", width: 250, height: 250, borderRadius: "50%", background: "rgba(124,58,237,0.05)", filter: "blur(70px)", pointerEvents: "none", animation: "float-orb 15s ease-in-out infinite reverse" }} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12 py-12">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="mb-10"
        >
          <div className="flex items-center gap-3 mb-3">
            <div style={{ width: 30, height: 1, background: "#00ff88" }} />
            <span style={{ fontFamily: "'DM Mono', monospace", fontSize: "0.7rem", letterSpacing: "0.2em", color: "#00ff88" }}>
              NEXUS '26 — PROGRAM
            </span>
          </div>
          <h1 style={{
            fontFamily: "'Space Grotesk', sans-serif",
            fontSize: "clamp(2.5rem, 7vw, 5.5rem)",
            fontWeight: 700,
            letterSpacing: "-0.03em",
            color: "#ffffff",
            margin: 0,
            lineHeight: 0.95,
          }}>
            THE SCHEDULE
          </h1>
          <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: "1rem", color: "rgba(255,255,255,0.45)", marginTop: "1rem", maxWidth: 500 }}>
            {talks.length} talks across 3 days and 4 tracks. Filter below to find your sessions.
          </p>
        </motion.div>

        {/* Filter bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          style={{
            background: "rgba(255,255,255,0.025)",
            border: "1px solid rgba(255,255,255,0.08)",
            borderRadius: "16px",
            padding: "1.25rem 1.5rem",
            marginBottom: "2rem",
          }}
        >
          {/* Mobile filter toggle */}
          <div className="flex items-center justify-between md:hidden mb-3">
            <span style={{ fontFamily: "'DM Mono', monospace", fontSize: "0.75rem", letterSpacing: "0.1em", color: "rgba(255,255,255,0.5)" }}>
              <Filter size={12} style={{ display: "inline", marginRight: "0.5rem" }} />
              FILTERS
            </span>
            <button
              onClick={() => setShowFilters(!showFilters)}
              style={{ background: "transparent", border: "none", color: "rgba(255,255,255,0.5)", cursor: "pointer" }}
            >
              {showFilters ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
            </button>
          </div>

          <div className={`${showFilters ? "block" : "hidden"} md:block`}>
            <div className="flex flex-col md:flex-row gap-4">
              {/* Day filter */}
              <div>
                <div style={{ fontFamily: "'DM Mono', monospace", fontSize: "0.65rem", letterSpacing: "0.15em", color: "rgba(255,255,255,0.3)", marginBottom: "0.6rem" }}>
                  DAY
                </div>
                <div className="flex flex-wrap gap-2">
                  {DAYS.map((day, i) => (
                    <motion.button
                      key={day}
                      whileHover={{ scale: 1.04 }}
                      whileTap={{ scale: 0.96 }}
                      onClick={() => setSelectedDay(day)}
                      style={{
                        fontFamily: "'DM Mono', monospace",
                        fontSize: "0.72rem",
                        letterSpacing: "0.08em",
                        padding: "0.45rem 0.9rem",
                        borderRadius: "8px",
                        border: "1px solid",
                        cursor: "pointer",
                        transition: "all 0.2s ease",
                        ...(selectedDay === day
                          ? {
                              background: "#00ff88",
                              borderColor: "#00ff88",
                              color: "#050508",
                              fontWeight: 600,
                              boxShadow: "0 0 15px rgba(0,255,136,0.3)",
                            }
                          : {
                              background: "transparent",
                              borderColor: "rgba(255,255,255,0.12)",
                              color: "rgba(255,255,255,0.55)",
                            }),
                      }}
                    >
                      {DAY_SHORT[i]}
                    </motion.button>
                  ))}
                </div>
              </div>

              {/* Divider */}
              <div style={{ width: 1, background: "rgba(255,255,255,0.07)", margin: "0 0.5rem", display: "none" }} className="md:block" />

              {/* Track filter */}
              <div>
                <div style={{ fontFamily: "'DM Mono', monospace", fontSize: "0.65rem", letterSpacing: "0.15em", color: "rgba(255,255,255,0.3)", marginBottom: "0.6rem" }}>
                  TRACK
                </div>
                <div className="flex flex-wrap gap-2">
                  {TRACKS.map((track) => {
                    const tc = TRACK_COLORS[track];
                    const isActive = selectedTrack === track;
                    const count = counts[track as keyof typeof counts] ?? 0;
                    return (
                      <motion.button
                        key={track}
                        whileHover={{ scale: 1.04 }}
                        whileTap={{ scale: 0.96 }}
                        onClick={() => setSelectedTrack(track)}
                        style={{
                          fontFamily: "'DM Mono', monospace",
                          fontSize: "0.72rem",
                          letterSpacing: "0.08em",
                          padding: "0.45rem 0.9rem",
                          borderRadius: "8px",
                          border: "1px solid",
                          cursor: "pointer",
                          transition: "all 0.2s ease",
                          display: "flex",
                          alignItems: "center",
                          gap: "0.4rem",
                          ...(isActive
                            ? {
                                background: tc?.bg || "rgba(0,255,136,0.12)",
                                borderColor: tc?.text || "#00ff88",
                                color: tc?.text || "#00ff88",
                                boxShadow: `0 0 15px ${tc?.text || "#00ff88"}33`,
                              }
                            : {
                                background: "transparent",
                                borderColor: "rgba(255,255,255,0.12)",
                                color: "rgba(255,255,255,0.55)",
                              }),
                        }}
                      >
                        {track}
                        <span style={{
                          fontSize: "0.6rem",
                          background: isActive ? "rgba(255,255,255,0.2)" : "rgba(255,255,255,0.08)",
                          borderRadius: "4px",
                          padding: "0.1rem 0.35rem",
                          fontWeight: 600,
                        }}>
                          {count}
                        </span>
                      </motion.button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Results count */}
        <motion.div
          layout
          style={{
            fontFamily: "'DM Mono', monospace",
            fontSize: "0.72rem",
            letterSpacing: "0.1em",
            color: "rgba(255,255,255,0.35)",
            marginBottom: "1.5rem",
          }}
        >
          {filteredTalks.length} TALK{filteredTalks.length !== 1 ? "S" : ""} FOUND
          {selectedDay !== 0 && ` · ${DAY_LABELS[selectedDay]}`}
          {selectedTrack !== "All" && ` · ${selectedTrack} Track`}
        </motion.div>

        {/* Grid */}
        <LayoutGroup>
          <AnimatePresence mode="popLayout">
            {filteredTalks.length === 0 ? (
              <motion.div
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                style={{
                  textAlign: "center",
                  padding: "5rem 2rem",
                  border: "1px dashed rgba(255,255,255,0.1)",
                  borderRadius: "16px",
                  color: "rgba(255,255,255,0.3)",
                  fontFamily: "'DM Mono', monospace",
                  fontSize: "0.85rem",
                  letterSpacing: "0.1em",
                }}
              >
                NO TALKS MATCH YOUR FILTERS
              </motion.div>
            ) : (
              <motion.div layout className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {filteredTalks.map((talk, i) => (
                  <motion.div
                    key={talk.id}
                    layout
                    initial={{ opacity: 0, y: 20, scale: 0.97 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9, y: -10 }}
                    transition={{ duration: 0.25, delay: i * 0.03 }}
                  >
                    <TalkCard
                      talk={talk}
                      expanded={expandedId === talk.id}
                      onToggle={() => setExpandedId(expandedId === talk.id ? null : talk.id)}
                    />
                  </motion.div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </LayoutGroup>
      </div>
    </div>
  );
}
